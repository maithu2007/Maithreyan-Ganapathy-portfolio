MAITHREYAN CAREER PORTFOLIO — FREE WEBSITE

FILES
- index.html: website content
- style.css: black-and-purple design and responsive layout
- script.js: mobile navigation menu

HOW TO PREVIEW ON WINDOWS
1. Extract this ZIP into a folder, for example Desktop\maithreyan-career-portfolio.
2. Double-click index.html. It opens in your browser.
3. To edit, right-click index.html and choose Open with > Notepad (or use VS Code if installed).
4. Edit style.css for design changes.

IMPORTANT BEFORE SHARING
- In index.html, replace YOUR.EMAIL@example.com with your real professional email.
- Update GitHub and LinkedIn links with your actual profile URLs.
- Keep skills accurate; remove technologies you cannot yet explain.
- Project cards 2 and 3 are clearly labelled as ideas. Replace them with completed projects when ready.
- Add your resume only after creating a polished PDF resume.

FREE PUBLISHING WITH GITHUB PAGES
1. Sign in at https://github.com
2. Create a NEW PUBLIC repository named maithreyan-portfolio (or another name).
3. Upload index.html, style.css, and script.js at the repository root (not inside an extra nested folder).
4. Click Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait a few minutes. The website address will look like:
   https://YOUR-GITHUB-USERNAME.github.io/maithreyan-portfolio/
